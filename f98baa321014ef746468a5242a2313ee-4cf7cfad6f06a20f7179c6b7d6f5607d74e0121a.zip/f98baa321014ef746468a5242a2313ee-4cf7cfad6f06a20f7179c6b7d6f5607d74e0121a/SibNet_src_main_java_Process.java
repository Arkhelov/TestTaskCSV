public class Process {
    public String id;
    public String processName;
    public String subdivision;

}
